<?php
// Heading
$_['heading_title'] = 'OpenCart Facebook Messenger';
$_['entry_status'] = 'Status';

// Text
$_['text_success'] = 'Success: You have modified module OpenCart Facebook Messenger!';
$_['text_fb_sdk'] = 'Facebook JavaScript SDK';
 

//Error
$_['error_permission'] = 'Warning: You do not have permission to modify module OpenCart Facebook Messenger!';
$_['error_fb_sdk'] = 'Facebook JavaScript is required...';
?>